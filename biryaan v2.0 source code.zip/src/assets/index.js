export { default as logo } from "./logo.svg";
export { default as pinterest } from "./icons/pinterest.svg";
export { default as facebook } from "./icons/facebook.svg";
export { default as instagram } from "./icons/instagram.svg";
