export { default as Home } from "./Home";
export { default as Terms } from "./Terms";
export { default as Franchise } from "./Terms";
